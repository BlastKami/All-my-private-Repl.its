

import sys
file = open("Your STORAGE","a")


override = 'test'



repeaterstop = ()

blanktaidatstorage1 = []
retry = 'yes'
class Parent():
  def __init__ (self):  #parent constructor
    print("Parent constructor called")
  def show_info(self):
 
def datasaver():
  print('Input numberical password to save data')  
  newdata = input('Oof input your numbericalpassword to save data again.')
  if newdata == 5454 or override == 'test':
    for x in range(1,5):
      print(newdata, 'Hi data has been saved to this PC')
    for x in range(0,1):
      file.write(newdata)
      blanktaidatstorage1.append(newdata)
      print('Data saved')
    print(blanktaidatstorage1, "If empty try again.")
  elif blanktaidatstorage1 == blanktaidatstorage1:
    print('Data save fail')
  else:
    print('Denied')
    


def person1():
  if str(input('Enter your failsafe safeword Braxton Manchester')) == 'onetwothreefourfive':
    print('Hi')
    for t in range(0,10):
      braxton = input('Are you braxton manchester')
      if braxton == 'yes':
        print('You are my demi-god why you do this to me braxton,k this is PYTHONIC, your god now')
      else:
        sys.exit()
    print('No your dead')
    sys.exit()
  else:
    sys.exit()
    

def tunneling():
  for e in range(1,10):
    file.write('for x in range(0,1) \n')
    file.write('  print("Gonna kill matheww with skynet when im done.") \n') 



class inputbackbone:
  global password
  def passwordchecker():
    global password
    password = 'Royalblast13'
    if input('Type security password') == password:
      print ('Access granted creator welcome to Machine learning-PYTHONIC')
      for a in range(0,5):
        print('Loading')      
        for c in range(1,3):
          print('...')
      print('Loaded welcome Tyler to PYTHONIC')
      print('Your personal machine learning program for you''re needs.')
      print('...........')
      print('Go ahead and input data')
    else:
      password += 'No'
      for a in range(1,3):
        print('access denied')
        break
  def inputproto():
    global password
    while password == 'Royalblast13':
      aistorage1 = input('1st input')
      aistorage2 = input('2cd input if needed')
      aistorage3 = input('3rd input if needed')
      aistorage4 = input('4th input if needed')
      aistorage5 = input('5th input if needed')
      file.write(aistorage1+"\n")
      file.write(aistorage2+"\n")
      file.write(aistorage3+"\n")
      file.write(aistorage4+"\n")
      file.write(aistorage5+"\n")
      datasaver()
      print('Remember all inputs are stored, Input your data carefully')
      if input('Do you want to stop taking input?'):
        sys.exit
      if input('Would you like to repeat your data and input more data?. Type Yes for repeat and or No to stop and save data.') == 'Yes':
        for x in range(int(input('Repeating 1st input'))):
          print(aistorage1)
        for a in range(int(input('Repeating 2cd input'))):
          print(aistorage2)
        for z in range(int(input('Repeating 3rd input'))):
          print(aistorage3)
        for c in range(int(input('Repeating 4th input'))):
          print(aistorage4)
        for d in range(int(input('Repeating 5th input'))):
          print(aistorage5) 
        for y in range (0,2):
          print('Repteating')
        for j in range(0,10):
          print('Repeated')
      else:
        tunneling()
  passwordchecker()
  inputproto()

inputbackbone()

