#Mr. Faulkner's alternating colored squares

import turtle

bob = turtle.Turtle()
bob.speed(1000)
colors = ["blue","red","yellow","violet","green"]



def draw_squares():
  for x in range(4):
    for y in range(4):
      bob.begin_fill()
      bob.forward(50)
      bob.right(90)
    bob.left(90)
    bob.fillcolor(colors[x])
    bob.end_fill()

draw_squares()

bob.penup()
bob.forward(200)
bob.pendown()

draw_squares()

bob.penup()
bob.left(90)
bob.forward(200)
bob.pendown()

draw_squares()

bob.penup()
bob.left(90)
bob.forward(200)
bob.pendown()

draw_squares()