my_file = open("newfile.txt", "w")
my_file.write("Your message is here!\n")
def timestable(num):
  for y in range(1,13):
    my_file.write(str(y)+" x " +str(num)+ " = " +str(y*num) +"\n")
timestable(2)
my_file.close()