var str = "we are the owasso rams"
var re = /^owasso/i
var x = re.test(str)
console.log(x);