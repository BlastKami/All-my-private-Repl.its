using System;
class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Hello World");
    Console.WriteLine ("this will be for all timne when we stat falling down into the death abyss of the world where we smight die by the end of the hand of Horua Lupercal.............. be warned my brothers.");
    var k1 = 500;
    var k2 = 600000 - k2;
    var k3 = 1
    Console.WriteLine (k1 + k3 + k2);
  }
}