while True:
  try:
    age = int(input('Enter your age.'))
  except ValueError:
    print('Enter whole numbers.')
  else:
    if age < 21:
      print('Get outta here!')
      break
    else:
      print('Welcome.')
      break
  