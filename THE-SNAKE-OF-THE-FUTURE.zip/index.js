window.onload=function(){
  canvas = document.getElementById("snake");
  pen = canvas.getContext("2d");
  document.addEventListener("keydown", keyPush);
  setInterval(ripoffgame,1000/15);
};
// THESE ARE GLOBAL VARIABLES SO NO VAR. var bad for snake games=

// set the player x and y pos

player_x = 10;
player_y = 10;

grid_size = 20;
tile_count = 

// set the p l a y e r x and y speed.
x_speed = 0;
y_speed = 0;

apple_x = 15;
apple_y = 15;

// snake postion
trail = [];
// starting length of snake
tail = 5;


// G A M E L O O G I C
function ripoffgame() {
  // update player postion
  player_x+=x_speed;
  player_y+=y_speed;
  pen.fillStyle = "Black";
  pen.fillRect(0,0,canvas.width,canvas.height);
  // snake bounds
  if(player_x < 0) {
    player_x = tile_count -1;
    
  }
  if(player_x < tile_count -1) {
    player_x =0;
    
  }
  if(player_y < 0) {
    player_y = tile_count -1;
    
  }
  if(player_y < tile_count -1) {
    player_y = 0;
    
  }
  // snake
  for(var i=0;i<trail.length;i++) {
    
  }
  // detect apple collision
  
  // track snake tail.
  trail.push({x:player_x,y:player_y})
  
  // apple  
  pen.fillStyle="red";
  pen.fillRect(apple_x*grid_size, apple_y*grid_size,grid_size, grid_size);
}
function keyPush(evt) {
  switch(evt.keyCode){
    case 37: // left
      x_speed = -1;
      y_speed = 0;
      break;
    case 38: // up
      x_speed = -1;
      y_speed = -1;
      break;
    case 39: // right
      x_speed = 1;
      y_speed = 0;
      break;
    case 40: // down
      y_speed = 1;
      x_speed = 0;
      break;
  }
}