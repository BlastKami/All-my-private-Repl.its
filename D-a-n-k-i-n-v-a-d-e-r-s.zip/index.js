 window.onload = function(){
  canvas = document.createElement("canvas");
  canvas.width = 640;
  canvas.height = 480;
  // adding the canvas to the HTML
  pen = canvas.getContext('2d');
  document.addEventListener('keydown',keyPush)
  // SET THE F P S
  var fps = 30;
  setInterval(update,1000/fps)
}


player_x =player_y = 100;
player_speed = 15;
player_dim = 30;

// enemy stats
enemylist = [];
enemy_dim = 25;
enemy_speed = 5;

// shot stats
shot_list = [];
shot_dim = 4;
shot_speed = 7;

function update(){
  pen.fillStyle="black";
  pen.fillRect(0, 0, canvas.width,canvas.height);
  
}


function keyPush(evt){
  switch(evt.keyCode){
    case 32: // spacebar
      break;
      
    case 37: // left
      player_x -= player_speed
      break;
      
    case 38: //up
      player_y += player_speed;
      break;
      
    case 39: // down arrow
      break;
      
    case 40: // down arrow
      break;
  }
}