/*
//string methods
var doh = "dough boy";
console.log(doh.toUpperCase()); //toUpperCase makes it uppercase
console.log(doh.split(" ")); //splits the space from the string making the seperate words seperate strings in a array.
console.log(doh.charAt(0)); // finds and prints the character at zero which would be D.

// SSSSSSSSSSSSSPAAAAAAAAAAAAAAAAAAAACEEEEEEEEEEEEEER
// ONTO OBJECTS!
// objects

var person = {name:"Kim", age:88}; // very basic object.
console.log(person);
console.log(person.name);
console.log(person.age);
//adding properties to the object

person.title = "Mrs.";
console.log(person.title);

// modify the properties

person.name = "Kimberly";
person.gender = "Female";
console.log(person);

// deleting properties

delete person.title;
console.log(person);

//comparing properties

console.log(person.name.length > person.gender.length > person);
*/

// array of objects
var people = [
  {name:"Kim", age:88},
  {name:"bill", age:55},
  {name:"bob", age:34},
  {name:"bobby", age:15}
  ];
console.log(people[1].name);
//create a loop to print all the names.
for(i=0;i<people.length;i++){
  console.log(people[i].name)
}



