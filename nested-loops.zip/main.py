import random
import time

min = 1
max = 2


option1 = 'Do it'
option2 = 'Your future is bright'
option3 = 'Do it for the meme'
option4 = 'No'
option5 = 'Life is the answer'
option6 = 'Yaaaaaaaaaas'
option7 = 'is life truely real enough for you to do what you said young Anakin Skywalker'


def animation():
  for x in range(3):
    time.sleep(.5)
    print('.')

roll_again = 'yes'

while roll_again == 'yes' or roll_again =='y':
  print('Ask me anything.....')
  input()
  choices = random.randint(min, max)
  if choices == 1:
    print(option1)
  elif choices == 2:
    print(option2)
  elif choices == 3:
    print(option3)
  elif choices == 4:
    print(option4)
  elif choices == 5:
    print(option5)
  elif choices == 6:
    print(option6)
  roll_again = input()
