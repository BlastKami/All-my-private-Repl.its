#This code will allow your turtle move around using the arrow keys
#Create a maze for your turtle to navigate to.

import turtle
player1 = turtle.Turtle()
scr = turtle.Screen()
maze = turtle.Turtle()
maze.speed("fastest")
maze2 = turtle.Turtle()
maze2.speed("fastest")
maze3 = turtle.Turtle()
maze3.speed("fastest")
maze3.fd(240)
maze3.rt(90)
maze3.fd(60)
maze3.lt(90)
maze3.fd(120)
maze3.lt(90)
maze3.fd(30)
maze3.lt(90)
maze3.lt(90)
maze3.fd(30)
maze3.lt(90)
maze3.fd(60)
maze3.lt(30)
maze3.fd(30)



maze2.fd(240)
maze2.penup()
maze2.fd(60)
maze2.pendown()
maze2.fd(30)
maze2.rt(90)
maze2.fd(30)
maze2.rt(90)
maze2.rt(90)
maze2.fd(30)
maze2.rt(90)
maze2.fd(60)





maze.fd(240)
maze.penup()
maze.fd(60)
maze.pendown()
maze.fd(240)
maze.rt(90)
maze.fd(240)
maze.rt(90)
maze.fd(360)
maze.penup()
maze.fd(60)
maze.pendown()
maze.fd(120)
maze.rt(90)
maze.fd(240)
maze.rt(90)
maze.fd(240)
maze.rt(90)
maze.fd(60)
maze.lt(90)
maze.fd(60)
maze.lt(90)
maze.fd(30)
maze.lt(180)
maze.fd(30)
maze.lt(90)
maze.fd(120)
maze.rt(90)
maze.fd(30)
maze.lt(90)
maze.fd(60)
maze.rt(180)
maze.fd(30)
maze.lt(90)
maze.fd(90)
maze.rt(90)
maze.fd(240)

def m1():    #moves player1 up
    player1.setheading(90)
    player1.fd(15)
    player1.pos()
    print(player1.pos())

def m2():    #moves player1 left
    player1.setheading(180)
    player1.fd(15)
    player1.pos()
    print(player1.pos())

def m3():    #moves player1 right
    player1.setheading(360)
    player1.fd(15)
    player1.pos()
    print(player1.pos())

def m4():    #moves player1 down
    player1.setheading(-90)
    player1.fd(15)
    player1.pos()
    print(player1.pos())

scr.onkey(m1, "Up")
scr.onkey(m2, "Left")
scr.onkey(m3, "Right")
scr.onkey(m4, "Down")

player1.penup()   #this is so it doesn't leave a trail.
    
scr.listen()