import turtle

import time

clock = turtle.Turtle()
clock.speed(0)


for tick in range(0,12):
  clock.up()
  clock.forward(80)
  clock.down()
  clock.fd(10)
  clock.up()
  clock.fd(30)
  clock.stamp()
  clock.backward(120)
  clock.left(30)

  
clock.ht()

sc = turtle.Turtle()
sc.speed(0)
sc.color("red")

mn = turtle.Turtle()
mn.speed(0)

hr = turtle.Turtle()
hr.color("blue")
hr.speed(0)
hr.pensize(10)

update = True
updatemin = True
updatehour = True

while True:
  b = time.gmtime(time.time())
  b = time.localtime()
  min = b.tm_min
  sec = b.tm_sec
  if update == True:
    sc.lt(90)
    sc.pensize(1)
    sc.right((sec)*6)
    sc.fd(120)
    update = False
  if updatemin == True:
    mn.lt(90)
    mn.pensize(3)
    mn.right((min)*6)
    mn.fd(120)
    updatemin = False
  if updatehour == True:
    hr.lt(90)
    hr.pensize(3)
    hr.right(((b.tm_hour) % 12) * 30 + min * 0.5)
    hr.fd(90)
    updatehour = False
  time.sleep(0.1)
  b = time.gmtime(time.time())
  b = time.localtime()
  new_min = b.tm_min
  new_sec = b.tm_sec

  if new_min != min:
    updatemin = True
    mn.home()
    mn.clear()
  if new_sec != sec:
    update = True
    sc.home()
    sc.clear()
