testingvariable = 1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000

for x in range(testingvariable):
  print('Hey now your a rockstr you''re your a amazng memememememmememe' + str(testingvariable))