my_file = open("newfile.txt", "a")
my_file.write("File opened \n")


def upkeeper():
  my_file.write(input("Save Y or N?"))
  my_file.write("Progess saved\n")
 
upkeeper()

my_file.close()