#print number of 4's in a list
#def means define
def count_4s(array1):
  count = 0
  for x in array1:
    if x == 4:
      count = count +1 #adds to the count by one me
      #you put a variable after return such as count
  return count
  
list1 = [2,6,8,4,4,3,8,4]
list2 = [0,1,2,3,8,9]

print (count_4s(list1))
print (count_4s(list2))