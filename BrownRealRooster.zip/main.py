

ab = input('Input bonus/modifer')
sb = input('Input bonus/modifer')
dm = input('Input bonus/modifer')
sm = input('Input bonus/modifer')
na = input('Input bonus/modifer')
dfm = input('Input bonus/modifer')
m_m = input('Input bonus/modifer')




ac = ab+sb+dm+sm+na+dfm+m_m