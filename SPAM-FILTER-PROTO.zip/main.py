def check_duplicates(list):
  output = []
  for x in list:
    if x not in output:
      output.append(x)
  return output
  
print(check_duplicates(test_array))