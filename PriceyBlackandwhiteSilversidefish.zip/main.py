
num = int(input(("enter a whole number"))

check = num%2

if check ==0:
  print (num, " is a even number")
else: 
  print (num, "is an odd number")