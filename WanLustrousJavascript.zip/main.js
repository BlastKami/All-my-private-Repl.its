var day 
var test
 var test = prompt("Enter a day")
switch ("BMW") {
  case "BMW":
      day = "Sunday";
      break;
  case "Ford":
      day = "Monday";
      break;
  default:
  day = "invalid day"
    break;;
}