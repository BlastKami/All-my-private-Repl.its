import turtle
import random

window = turtle.Screen()
window.bgcolor("white")

bob = turtle.Turtle()
bob.speed("fastest")
bob.color("teal")

num =random.randint(150,500)
angle = random.randint(1,360)

def draw_star():
  for x in range(60):
    bob.forward(50)
    bob.right(170.2)
    bob.forward(150)

for x in range(0,100000):
  num =random.randint(200,500)
  bob.penup()
  bob.forward(100)
  bob.lt(angle)
  bob.pendown()
  draw_star()
  bob.penup()
  bob.forward(num)
  bob.lt(angle)
  bob.forward(num)
  bob.rt(angle)
