import turtle #This import command allows you to use turtle in your code.

yourname = turtle.Turtle() #this makes you a turtle bot.
#First lets change the color, to do this you do this command.
yourname.color('black') #if you want to change the color then replace black with say red,blue,yellow, or green.

yourname.speed('fastest')#Now there are several ways to do this but to save time we will go with fastest for theese exercises.

#this is a list of basic commands.

yourname.forward(100)#This makes your turtle go forward.
yourname.backward(100)#this makes your turtle go backwards.
yourname.right(90)#this makes your turtle take a 90 degree turn right
yourname.left(90)#This makes your turtle take a 90 degree turn left.
yourname.penup()#this makes your pen/brush go up so any movements after this makes the trail of your turtle blank/invisible.
yourname.pendown()#This will make your pen/brush go back down and your trail visible again.
#okay time to draw a box follow along!!
yourname.forward(100)#This makes us go forward now we need to turn right.
yourname.right(90)#This makes us turn right
#now we can put this in a for loop and have it run itself.
for x in range(1,4):#for the range you start with 1, and then we need to repeat 4 times
  yourname.forward(100)
  yourname.right(90)
#You did you made your first turtle drawing.

