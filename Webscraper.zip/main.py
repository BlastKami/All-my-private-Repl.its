import requests
from bs4 import BeautifulSoup 
url = 'http://www.foxnews.com/' #change the HTML
r = requests.get(url)
r_html = r.text

soup = BeautifulSoup(r_html,"lxml")


# this will fetch all of the links on a webpage
for story in soup.find_all("div",class_="title" or "headline" or "show"): #change the variables the headline or such with the name of the classes in the HTML
	print(story.text.replace("\n", "").strip())


