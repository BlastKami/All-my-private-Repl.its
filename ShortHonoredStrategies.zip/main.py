count1 = 0
for x in range(0,10):
  print('Meme')
  print('Deh Meme')
  for x in range(0,100):
    print('When this used to be hard lol')
    count1 += 1
    print(count1)